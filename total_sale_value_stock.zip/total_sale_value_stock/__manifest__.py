{
    'name': 'Total Sale Value in Stock Report',
    'version': '17.0.0.1',
    'summary': 'Adds a Total Sale Value column to stock product view.',
    'description': '''
        This module enhances the stock product list view by adding a new column, "Total Sale Value". 
        The Total Sale Value is calculated as the product of the quantity on hand and the list price 
        of each product. This column provides an immediate view of the total potential sale value for 
        each product available in stock, which can assist in stock valuation and sales potential analysis.

        Key Features:
        - Adds "Total Sale Value" column to stock product tree view.
        - Dynamically calculates total sale value based on the quantity on hand and list price.
        - Easy-to-install, providing valuable insights for stock management.

        Ideal for companies that want to monitor stock value based on potential sales at the product's 
        listed price and make informed stock management decisions.
    ''',
    'author': 'Outsetx',
    'maintainer': 'M Jamshaid',
    'website': 'https://outsetx.com',
    'category': 'Inventory',
    'depends': ['stock'],
    'data': [
        'views/product_product_stock_tree_view.xml',
    ],
    'installable': True,
    'application': False,
    'license': 'LGPL-3',
}
