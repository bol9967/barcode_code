
from odoo import fields, models, api

class ProductProduct(models.Model):
    _inherit = 'product.product'

    total_sale_value = fields.Float(
        string='Total Sale Value',
        compute='_compute_total_sale_value',
        store=True
    )

    @api.depends('qty_available', 'list_price')
    def _compute_total_sale_value(self):
        for product in self:
            product.total_sale_value = product.qty_available * product.list_price
