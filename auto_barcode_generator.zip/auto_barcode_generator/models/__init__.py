from . import res_company
from . import res_config_settings
from . import product_barcode_generator
