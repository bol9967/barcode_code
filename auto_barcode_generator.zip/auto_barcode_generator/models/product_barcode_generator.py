from odoo import fields, models, api, _
from odoo.exceptions import UserError
try:
    import barcode
    _lib_imported = True
except ImportError:
    _lib_imported = False
import random

import werkzeug.exceptions
import base64


def get_random_number():
    random_num = str(random.randint(10000000000, 99999999999))
    random_first_digit = random.randint(1, 9)
    random_str = str(random_first_digit) + ''.join(map(str, random_num[:11]))
    return random_str


def generate_ean(barcode_type):
    if not _lib_imported:
        raise UserError(
            _('python-barcode is not installed. Please install it.'))
    EAN = barcode.get_barcode_class(barcode_type)
    ean = EAN(get_random_number())
    return ean.get_fullcode()


class ProductTemplate(models.Model):
    _inherit = 'product.template'

    auto_product_barcode_img = fields.Binary(
        string="Barcode Image", readonly=True)

    def action_generate_barcode_image(self):
        self.ensure_one()
        if self.barcode:
            img_barcode = self.env['ir.actions.report'].barcode(
                'Code128', self.barcode, width=500, height=90, humanreadable=0)
            self.auto_product_barcode_img = base64.b64encode(img_barcode)

    def generate_barcode_image(self, ean):
        # generate Barcode image
        try:
            ean_barcode = self.env['ir.actions.report'].barcode(
                'EAN13', ean, width=500, height=90, humanreadable=0)
            if ean_barcode:
                self.auto_product_barcode_img = base64.b64encode(ean_barcode)

        except (ValueError, AttributeError):
            raise werkzeug.exceptions.HTTPException(
                description='Cannot convert into barcode.')

    def action_generate_barcode(self):
        if self:
            for rec in self:
                ean = generate_ean(self.env.company.auto_barcode_type)
                rec.barcode = ean
                rec.generate_barcode_image(ean)


class autoProductProduct(models.Model):
    _inherit = 'product.product'

    def action_generate_barcode_image(self):
        self.ensure_one()
        if self.barcode:
            img_barcode = self.env['ir.actions.report'].barcode(
                'Code128', self.barcode, width=500, height=90, humanreadable=0)
            self.auto_product_barcode_img = base64.b64encode(img_barcode)

    def action_generate_barcode(self):
        if self:
            for rec in self:
                ean = generate_ean(self.env.company.auto_barcode_type)
                rec.barcode = ean
                rec.generate_barcode_image(ean)

    def generate_barcode_image(self, ean):
        # generate Barcode image
        try:
            ean_barcode = self.env['ir.actions.report'].barcode(
                'EAN13', ean, width=500, height=90, humanreadable=0)
            if ean_barcode:
                self.auto_product_barcode_img = base64.b64encode(ean_barcode)

        except (ValueError, AttributeError):
            raise werkzeug.exceptions.HTTPException(
                description='Cannot convert into barcode.')

    @api.model_create_multi
    def create(self, vals_list):
        res = super(autoProductProduct, self).create(vals_list)
        if self.user_has_groups('auto_barcode_generator.group_barcode_generator') and self.env.company.generate_barcode_on_product:
            # Filter out no barcode products 
            barcode_not_generated_product = res.filtered(
                lambda product: not product.barcode)
            for product in barcode_not_generated_product:
                # generate product barcode
                ean = generate_ean(self.env.company.auto_barcode_type)
                product.barcode = ean
                product.generate_barcode_image(ean)

        return res


class GenerateProductBarcode(models.Model):
    _name = 'generate.product.barcode'
    _description = 'Generate Product Barcode'

    # Generate Barcode for Existing Product
    overwrite_existing = fields.Boolean("Overwrite Barcode If Exists")

    def generate_barcode(self):
        if self.user_has_groups('auto_barcode_generator.group_barcode_generator'):

            context = dict(self._context or {})
            active_ids = context.get('active_ids', []) or []
            active_model = context.get('active_model', []) or []

            if active_model == 'product.product':
                for record in self.env['product.product'].browse(active_ids):

                    new_barcode = ''
                    if record.id:
                        new_barcode = generate_ean(
                            self.env.company.auto_barcode_type)
                        if self.overwrite_existing:  # Overwrite existing
                            record.barcode = new_barcode
                            record.generate_barcode_image(new_barcode)
                        else:
                            if not record.barcode:  # If barcode exists,then don't overwrite, Else generate New
                                record.barcode = new_barcode
                                record.generate_barcode_image(new_barcode)

            elif active_model == 'product.template':
                for record in self.env['product.template'].browse(active_ids):
                    new_barcode = ''
                    if record.id:
                        new_barcode = generate_ean(
                            self.env.company.auto_barcode_type)
                        if self.overwrite_existing:  # Overwrite existing
                            record.barcode = new_barcode
                            record.generate_barcode_image(new_barcode)
                        else:
                            if not record.barcode:  # If barcode exists,then don't overwrite, Else generate New
                                record.barcode = new_barcode
                                record.generate_barcode_image(new_barcode)

            return {'type': 'ir.actions.act_window_close'}

        else:
            raise UserError(
                _("You don't have rights to generate product barcode"))
